# API Documentation for QobuzDownloader v2.0

## Overview

The QobuzDownloader v2.0 API provides a set of endpoints for interacting with the Qobuz music streaming service. This documentation outlines the available endpoints, request parameters, and response formats.

## Base URL

The base URL for the API is:

```
https://api.qobuz.com
```

## Authentication

All requests to the API require authentication. You must include an `Authorization` header with your API key.

```
Authorization: Bearer YOUR_API_KEY
```

## Endpoints

### 1. Get Track Information

**Endpoint:** `/tracks/{track_id}`  
**Method:** `GET`  
**Description:** Retrieve detailed information about a specific track.

#### Parameters

- `track_id` (string): The unique identifier for the track.

#### Response

```json
{
  "id": "track_id",
  "title": "Track Title",
  "artist": "Artist Name",
  "album": "Album Name",
  "duration": 180,
  "release_date": "YYYY-MM-DD",
  "cover": "URL to cover image",
  "stream_url": "URL to stream the track"
}
```

### 2. Search Tracks

**Endpoint:** `/search/tracks`  
**Method:** `GET`  
**Description:** Search for tracks based on a query string.

#### Parameters

- `query` (string): The search term.
- `limit` (integer, optional): The number of results to return (default is 10).

#### Response

```json
{
  "results": [
    {
      "id": "track_id",
      "title": "Track Title",
      "artist": "Artist Name",
      "album": "Album Name",
      "duration": 180,
      "cover": "URL to cover image"
    }
  ],
  "total": 100
}
```

### 3. Download Track

**Endpoint:** `/tracks/{track_id}/download`  
**Method:** `POST`  
**Description:** Initiate a download for a specific track.

#### Parameters

- `track_id` (string): The unique identifier for the track.

#### Request Body

```json
{
  "format": "flac" // or "mp3"
}
```

#### Response

```json
{
  "download_url": "URL to download the track",
  "status": "success"
}
```

## Error Handling

The API returns standard HTTP status codes to indicate the success or failure of a request. Common error responses include:

- `400 Bad Request`: The request was invalid.
- `401 Unauthorized`: Authentication failed.
- `404 Not Found`: The requested resource was not found.
- `500 Internal Server Error`: An error occurred on the server.

## Rate Limiting

To ensure fair usage, the API enforces rate limits. Exceeding the limit will result in a `429 Too Many Requests` response.

## Conclusion

This API documentation provides a comprehensive overview of the endpoints available in QobuzDownloader v2.0. For further details, please refer to the specific endpoint sections or contact support for assistance.