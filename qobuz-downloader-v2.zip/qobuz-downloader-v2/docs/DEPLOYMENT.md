# DEPLOYMENT.md

## Deployment Guide for QobuzDownloader v2.0

This document outlines the steps required to deploy the QobuzDownloader v2.0 application, including both the frontend and backend components.

### Prerequisites

Before deploying the application, ensure that you have the following installed:

- Node.js (version 14 or higher)
- npm (Node Package Manager)
- TypeScript (for the server)
- A suitable database (if applicable)

### Frontend Deployment

1. **Build the Frontend**

   Navigate to the frontend directory and run the following command to build the application:

   ```bash
   cd qobuz-downloader-v2
   npm install
   npm run build
   ```

   This will create a production-ready build in the `dist` directory.

2. **Serve the Frontend**

   You can serve the built application using a static file server or deploy it to a hosting service like Vercel, Netlify, or GitHub Pages. For local testing, you can use:

   ```bash
   npm install -g serve
   serve -s dist
   ```

### Backend Deployment

1. **Setup the Server**

   Navigate to the server directory and install the necessary dependencies:

   ```bash
   cd server
   npm install
   ```

2. **Configure Environment Variables**

   Create a `.env` file in the server directory based on the `.env.example` provided. Ensure to set the necessary environment variables, such as API keys and database connection strings.

3. **Build the Server**

   If you are using TypeScript, compile the server code:

   ```bash
   tsc
   ```

4. **Run the Server**

   Start the server using the following command:

   ```bash
   npm start
   ```

   The server should now be running on the specified port (default is usually 3000).

### Testing the Deployment

After deploying both the frontend and backend, ensure that the application is functioning correctly by performing the following checks:

- Access the frontend application in your browser.
- Test the audio streaming functionality.
- Verify that downloads are working as expected.
- Check the API endpoints using tools like Postman or curl.

### Troubleshooting

If you encounter issues during deployment, consider the following:

- Check the console for any error messages.
- Ensure that all environment variables are correctly set.
- Verify that the server is running and accessible.
- Review the network requests in the browser's developer tools for any failed requests.

### Conclusion

Following these steps will help you successfully deploy the QobuzDownloader v2.0 application. For further assistance, refer to the documentation or seek help from the community.