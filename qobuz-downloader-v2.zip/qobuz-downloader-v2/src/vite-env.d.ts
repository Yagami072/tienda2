// vite-env.d.ts
/// <reference types="vite/client" />