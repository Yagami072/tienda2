import React from 'react';

interface DownloadProgressProps {
  progress: number; // Progress percentage (0 to 100)
  trackName: string; // Name of the track being downloaded
}

const DownloadProgress: React.FC<DownloadProgressProps> = ({ progress, trackName }) => {
  return (
    <div className="download-progress">
      <h4>{trackName}</h4>
      <div className="progress-bar">
        <div className="progress" style={{ width: `${progress}%` }} />
      </div>
      <span>{progress}%</span>
    </div>
  );
};

export default DownloadProgress;