import React from 'react';
import { useDownloadQueue } from '../../hooks/useDownloadQueue';
import DownloadProgress from './DownloadProgress';

const DownloadQueue: React.FC = () => {
  const { downloads } = useDownloadQueue();

  return (
    <div className="download-queue">
      <h2>Download Queue</h2>
      {downloads.length === 0 ? (
        <p>No downloads in progress.</p>
      ) : (
        <ul>
          {downloads.map((download) => (
            <li key={download.id}>
              <span>{download.trackTitle}</span>
              <DownloadProgress downloadId={download.id} />
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default DownloadQueue;