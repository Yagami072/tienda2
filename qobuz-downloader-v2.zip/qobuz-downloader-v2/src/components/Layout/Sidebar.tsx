import React from 'react';

const Sidebar = () => {
    return (
        <div className="sidebar">
            <h2>Navegación</h2>
            <ul>
                <li><a href="#audio">Reproducción de Audio</a></li>
                <li><a href="#downloads">Descargas</a></li>
                <li><a href="#search">Buscar</a></li>
            </ul>
        </div>
    );
};

export default Sidebar;