import React from 'react';
import { Track } from '../../../types/qobuz';

interface TrackListProps {
  tracks: Track[];
  onTrackSelect: (track: Track) => void;
}

const TrackList: React.FC<TrackListProps> = ({ tracks, onTrackSelect }) => {
  return (
    <div className="track-list">
      {tracks.length === 0 ? (
        <p>No tracks found.</p>
      ) : (
        <ul>
          {tracks.map((track) => (
            <li key={track.id} onClick={() => onTrackSelect(track)}>
              <span>{track.title}</span> - <span>{track.artist.name}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default TrackList;