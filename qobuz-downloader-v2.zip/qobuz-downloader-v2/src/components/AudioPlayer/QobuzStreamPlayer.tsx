import React, { useState, useRef } from 'react';

const QobuzStreamPlayer = ({ track, isPreviewMode = true }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const audioRef = useRef(null);
  const qobuzAPI = useRef(new QobuzAPI());

  const playTrack = async () => {
    if (isPlaying) {
      audioRef.current?.pause();
      setIsPlaying(false);
      return;
    }

    try {
      setIsLoading(true);

      const streamUrl = await qobuzAPI.current.getTrackStreamUrl(track.id, '27');

      if (audioRef.current) {
        audioRef.current.src = streamUrl;

        if (isPreviewMode) {
          audioRef.current.addEventListener('timeupdate', () => {
            if (audioRef.current.currentTime >= 30) {
              audioRef.current.pause();
              setIsPlaying(false);
            }
          });
        }

        await audioRef.current.play();
        setIsPlaying(true);
      }

    } catch (error) {
      console.error('Error playing track:', error);
      alert(`Error: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="stream-player">
      <audio ref={audioRef} />
      <button onClick={playTrack} disabled={isLoading}>
        {isLoading ? '⏳' : isPlaying ? '⏸️' : '▶️'}
      </button>
      <div className="track-info">
        <span>{track.title}</span>
        <span>{track.performer?.name}</span>
        {isPreviewMode && <span className="preview-badge">Preview (30s)</span>}
      </div>
    </div>
  );
};

export default QobuzStreamPlayer;