import { QobuzStreamPlayer } from './QobuzStreamPlayer';

export default QobuzStreamPlayer;