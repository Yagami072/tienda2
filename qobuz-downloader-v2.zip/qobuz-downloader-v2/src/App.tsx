import React from 'react';
import { Provider } from 'react-redux';
import { store } from './store';
import Header from './components/Layout/Header';
import Sidebar from './components/Layout/Sidebar';
import QobuzStreamPlayer from './components/AudioPlayer/QobuzStreamPlayer';
import DownloadQueue from './components/Download/DownloadQueue';
import SearchBar from './components/Search/SearchBar';
import './styles/globals.css';

const App = () => {
  return (
    <Provider store={store}>
      <div className="app-container">
        <Header />
        <Sidebar />
        <main>
          <SearchBar />
          <QobuzStreamPlayer />
          <DownloadQueue />
        </main>
      </div>
    </Provider>
  );
};

export default App;