// This file exports CacheManager. 

export { default as CacheManager } from './CacheManager';