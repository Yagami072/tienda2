import { configureStore } from '@reduxjs/toolkit';
import authReducer from './slices/authSlice';
import downloadReducer from './slices/downloadSlice';
import playerReducer from './slices/playerSlice';

const store = configureStore({
  reducer: {
    auth: authReducer,
    download: downloadReducer,
    player: playerReducer,
  },
});

export default store;