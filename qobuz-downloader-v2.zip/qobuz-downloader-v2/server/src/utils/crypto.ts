import { createHash } from 'crypto';

export const hashString = (input: string): string => {
    return createHash('sha256').update(input).digest('hex');
};

export const generateRandomBytes = (size: number): Buffer => {
    return Buffer.from(crypto.randomBytes(size));
};

export const verifyHash = (input: string, hash: string): boolean => {
    const inputHash = hashString(input);
    return inputHash === hash;
};