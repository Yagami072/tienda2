export const API_BASE_URL = 'https://www.qobuz.com/api.json/0.2';
export const APP_ID = '798273057';
export const CACHE_TTL_DOWNLOAD_URL = 30 * 60 * 1000; // 30 minutos
export const CACHE_TTL_APP_SECRET = 120 * 60 * 1000; // 120 minutos
export const CACHE_TTL_BUNDLE = 120 * 60 * 1000; // 120 minutos
export const BUNDLE_TIMEOUT = 45000; // 45 segundos
export const MAX_RETRIES = 3;
export const RETRY_DELAY_BASE = 1000; // 1 segundo
export const PREVIEW_DURATION = 30; // segundos

export const KNOWN_SECRETS = [
    'abb21364945c0583309667d13ca3d93a', // Ejemplo Sept 2025
    'f686f063cb0841079d48495d4dea7cf2',
    '05a4851e74ee47fda346f50cfdfc4f09',
    'c7c75df0fdd951e98fc22971e4acf8d2',
    '3b42129256f35f75923663b69a1f52b2'
];