class QobuzAPIServer {
    constructor() {
        this.baseUrl = 'https://www.qobuz.com/api.json/0.2';
        this.appId = '798273057';
    }

    async fetchTracks(query, limit = 50) {
        const params = new URLSearchParams({
            query: query,
            limit: limit.toString(),
            app_id: this.appId
        });

        const response = await fetch(`${this.baseUrl}/track/search?${params}`);
        if (!response.ok) {
            throw new Error(`Error fetching tracks: ${response.statusText}`);
        }

        const data = await response.json();
        return data.tracks.items;
    }

    async getTrackDetails(trackId) {
        const params = new URLSearchParams({
            track_id: trackId,
            app_id: this.appId
        });

        const response = await fetch(`${this.baseUrl}/track/getDetails?${params}`);
        if (!response.ok) {
            throw new Error(`Error fetching track details: ${response.statusText}`);
        }

        const data = await response.json();
        return data.track;
    }

    async getStreamingUrl(trackId, formatId = '27') {
        const params = new URLSearchParams({
            track_id: trackId,
            format_id: formatId,
            app_id: this.appId
        });

        const response = await fetch(`${this.baseUrl}/track/getFileUrl?${params}`);
        if (!response.ok) {
            throw new Error(`Error fetching streaming URL: ${response.statusText}`);
        }

        const data = await response.json();
        return data.url;
    }
}

export default QobuzAPIServer;