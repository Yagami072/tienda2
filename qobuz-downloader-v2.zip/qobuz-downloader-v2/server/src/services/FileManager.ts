class FileManager {
    constructor(basePath) {
        this.basePath = basePath;
    }

    async saveFile(fileName, data) {
        const filePath = `${this.basePath}/${fileName}`;
        try {
            await fs.promises.writeFile(filePath, data);
            console.log(`File saved: ${filePath}`);
        } catch (error) {
            console.error(`Error saving file: ${error.message}`);
            throw error;
        }
    }

    async readFile(fileName) {
        const filePath = `${this.basePath}/${fileName}`;
        try {
            const data = await fs.promises.readFile(filePath, 'utf-8');
            console.log(`File read: ${filePath}`);
            return data;
        } catch (error) {
            console.error(`Error reading file: ${error.message}`);
            throw error;
        }
    }

    async deleteFile(fileName) {
        const filePath = `${this.basePath}/${fileName}`;
        try {
            await fs.promises.unlink(filePath);
            console.log(`File deleted: ${filePath}`);
        } catch (error) {
            console.error(`Error deleting file: ${error.message}`);
            throw error;
        }
    }

    async fileExists(fileName) {
        const filePath = `${this.basePath}/${fileName}`;
        try {
            await fs.promises.access(filePath);
            return true;
        } catch {
            return false;
        }
    }
}

export default FileManager;