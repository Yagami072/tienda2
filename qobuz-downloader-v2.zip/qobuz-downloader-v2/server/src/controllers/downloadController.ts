import { Request, Response } from 'express';
import { DownloadService } from '../services/DownloadService';

class DownloadController {
    private downloadService: DownloadService;

    constructor() {
        this.downloadService = new DownloadService();
    }

    public async startDownload(req: Request, res: Response): Promise<void> {
        try {
            const { trackId } = req.body;
            const downloadUrl = await this.downloadService.startDownload(trackId);
            res.status(200).json({ downloadUrl });
        } catch (error) {
            res.status(500).json({ message: 'Error starting download', error: error.message });
        }
    }

    public async getDownloadProgress(req: Request, res: Response): Promise<void> {
        try {
            const { downloadId } = req.params;
            const progress = await this.downloadService.getDownloadProgress(downloadId);
            res.status(200).json({ progress });
        } catch (error) {
            res.status(500).json({ message: 'Error fetching download progress', error: error.message });
        }
    }

    public async cancelDownload(req: Request, res: Response): Promise<void> {
        try {
            const { downloadId } = req.params;
            await this.downloadService.cancelDownload(downloadId);
            res.status(200).json({ message: 'Download canceled successfully' });
        } catch (error) {
            res.status(500).json({ message: 'Error canceling download', error: error.message });
        }
    }
}

export default new DownloadController();