import { Request, Response } from 'express';
import { QobuzAPIServer } from '../services/QobuzAPIServer';

const qobuzAPI = new QobuzAPIServer();

export const getTrackStreamUrl = async (req: Request, res: Response) => {
    const { trackId, formatId } = req.params;

    try {
        const streamUrl = await qobuzAPI.getTrackStreamUrl(trackId, formatId);
        res.status(200).json({ url: streamUrl });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

export const searchTracks = async (req: Request, res: Response) => {
    const { query } = req.query;

    try {
        const tracks = await qobuzAPI.searchTracks(query);
        res.status(200).json(tracks);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Additional controller methods can be added here as needed.