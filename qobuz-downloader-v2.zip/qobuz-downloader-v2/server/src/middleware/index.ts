import cors from 'cors';
import { authenticate } from './auth';

export { cors, authenticate };