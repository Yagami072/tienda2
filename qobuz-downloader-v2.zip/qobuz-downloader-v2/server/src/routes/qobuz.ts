import { Router } from 'express';
import { getTracks, getTrackStreamUrl } from '../controllers/qobuzController';

const router = Router();

// Ruta para obtener pistas
router.get('/tracks', getTracks);

// Ruta para obtener la URL de streaming de una pista
router.get('/tracks/:id/stream', getTrackStreamUrl);

export default router;