import { Router } from 'express';
import { downloadController } from '../controllers/downloadController';

const router = Router();

// Route to start a download
router.post('/start', downloadController.startDownload);

// Route to get the status of a download
router.get('/status/:id', downloadController.getDownloadStatus);

// Route to cancel a download
router.delete('/cancel/:id', downloadController.cancelDownload);

export default router;