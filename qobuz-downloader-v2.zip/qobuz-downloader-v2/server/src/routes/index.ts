import { Router } from 'express';
import qobuzRoutes from './qobuz';
import downloadRoutes from './download';

const router = Router();

router.use('/qobuz', qobuzRoutes);
router.use('/download', downloadRoutes);

export default router;