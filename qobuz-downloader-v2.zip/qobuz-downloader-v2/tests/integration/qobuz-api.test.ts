import { QobuzAPI } from '../../src/services/qobuz/QobuzAPI';
import { QobuzApiSharp } from '../../src/services/qobuz/QobuzApiSharp';

describe('QobuzAPI Integration Tests', () => {
    let qobuzAPI: QobuzAPI;

    beforeAll(() => {
        qobuzAPI = new QobuzAPI();
    });

    test('should authenticate user successfully', async () => {
        const email = 'test@example.com';
        const password = 'password123';
        const userInfo = await qobuzAPI.login(email, password);
        expect(userInfo).toHaveProperty('email', email);
    });

    test('should search tracks successfully', async () => {
        const query = 'Danza Kuduro';
        const tracks = await qobuzAPI.searchTracks(query);
        expect(tracks).toBeInstanceOf(Array);
        expect(tracks.length).toBeGreaterThan(0);
    });

    test('should get streaming URL for a track', async () => {
        const trackId = '6989452'; // Example track ID
        const streamUrl = await qobuzAPI.getTrackStreamUrl(trackId);
        expect(streamUrl).toMatch(/^https?:\/\//); // Check if URL is valid
    });

    test('should handle errors gracefully', async () => {
        await expect(qobuzAPI.getTrackStreamUrl('invalid_id')).rejects.toThrow('Track not found');
    });

    afterAll(() => {
        // Clean up if necessary
    });
});