import { QobuzAPI } from '../../../src/services/qobuz/QobuzAPI';
import { jest } from '@jest/globals';

describe('QobuzAPI', () => {
  let qobuzAPI;

  beforeEach(() => {
    qobuzAPI = new QobuzAPI();
  });

  test('should initialize with default values', () => {
    expect(qobuzAPI.APP_ID).toBe('798273057');
    expect(qobuzAPI.BASE_URL).toBe('https://www.qobuz.com/api.json/0.2');
    expect(qobuzAPI.userAuthToken).toBeNull();
  });

  test('should login successfully', async () => {
    const email = 'test@example.com';
    const password = 'password123';

    // Mock the fetch function to simulate a successful login response
    global.fetch = jest.fn(() =>
      Promise.resolve({
        ok: true,
        json: () => Promise.resolve({
          user_auth_token: 'mockToken',
          user: { email },
        }),
      })
    );

    const userInfo = await qobuzAPI.login(email, password);
    expect(userInfo.email).toBe(email);
    expect(qobuzAPI.userAuthToken).toBe('mockToken');
  });

  test('should throw error on login failure', async () => {
    const email = 'test@example.com';
    const password = 'wrongPassword';

    // Mock the fetch function to simulate a failed login response
    global.fetch = jest.fn(() =>
      Promise.resolve({
        ok: false,
        status: 401,
      })
    );

    await expect(qobuzAPI.login(email, password)).rejects.toThrow('Login failed: 401');
  });

  test('should search tracks successfully', async () => {
    const query = 'Danza Kuduro';

    // Mock the fetch function to simulate a successful search response
    global.fetch = jest.fn(() =>
      Promise.resolve({
        ok: true,
        json: () => Promise.resolve({
          tracks: {
            items: [{ id: '6989452', title: 'Danza Kuduro' }],
          },
        }),
      })
    );

    const tracks = await qobuzAPI.searchTracks(query);
    expect(tracks.length).toBe(1);
    expect(tracks[0].title).toBe('Danza Kuduro');
  });

  test('should throw error on search failure', async () => {
    const query = 'Nonexistent Track';

    // Mock the fetch function to simulate a failed search response
    global.fetch = jest.fn(() =>
      Promise.resolve({
        ok: false,
        status: 404,
      })
    );

    await expect(qobuzAPI.searchTracks(query)).rejects.toThrow('Search failed: 404');
  });

  afterEach(() => {
    jest.clearAllMocks();
  });
});