import { encrypt, decrypt } from '../../src/utils/crypto';

describe('Crypto Utils', () => {
  const secretKey = 'mySecretKey';
  const data = 'Hello, World!';
  
  it('should encrypt and decrypt data correctly', () => {
    const encryptedData = encrypt(data, secretKey);
    const decryptedData = decrypt(encryptedData, secretKey);
    
    expect(decryptedData).toBe(data);
  });

  it('should throw an error when decrypting with an incorrect key', () => {
    const encryptedData = encrypt(data, secretKey);
    const wrongKey = 'wrongKey';

    expect(() => decrypt(encryptedData, wrongKey)).toThrow('Invalid key');
  });

  it('should return null when decrypting invalid data', () => {
    const invalidData = 'invalidData';

    const result = decrypt(invalidData, secretKey);
    expect(result).toBeNull();
  });
});