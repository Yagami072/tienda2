import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { QobuzStreamPlayer } from '../../src/components/AudioPlayer';
import { MockedProvider } from '@apollo/client/testing';
import { createMockTrack } from '../mocks/trackMocks';

describe('Download Flow E2E Tests', () => {
  it('should download a track successfully', async () => {
    const track = createMockTrack();

    render(
      <MockedProvider>
        <QobuzStreamPlayer track={track} />
      </MockedProvider>
    );

    const downloadButton = screen.getByRole('button', { name: /download/i });
    fireEvent.click(downloadButton);

    await waitFor(() => {
      expect(screen.getByText(/download successful/i)).toBeInTheDocument();
    });
  });

  it('should show error message on download failure', async () => {
    const track = createMockTrack();

    render(
      <MockedProvider>
        <QobuzStreamPlayer track={track} />
      </MockedProvider>
    );

    const downloadButton = screen.getByRole('button', { name: /download/i });
    fireEvent.click(downloadButton);

    await waitFor(() => {
      expect(screen.getByText(/download failed/i)).toBeInTheDocument();
    });
  });
});