# QobuzDownloader v2.0

## Descripción del Proyecto
QobuzDownloader v2.0 es una aplicación web moderna diseñada para descargar música de Qobuz. La aplicación ha sido migrada de un stack de Python a un stack basado en React y Node.js, utilizando TypeScript para una mejor gestión de tipos y una experiencia de desarrollo más robusta.

## Características Principales
- **Descargas Concurrentes**: Permite realizar múltiples descargas de manera eficiente con gestión de colas.
- **Soporte para FLAC**: Descarga música en alta calidad con soporte para archivos FLAC.
- **Integración de Metadatos**: Embebido de metadatos y carátulas en los archivos de audio descargados.
- **Seguimiento de Progreso**: Monitoreo en tiempo real del progreso de las descargas.
- **Sistema de Cola Avanzado**: Solo permite una descarga a la vez para evitar sobrecargas en la API.

## Tecnología Utilizada
- **Frontend**: React con TypeScript
- **Backend**: Node.js con Express
- **Framework UI**: Material-UI o Tailwind CSS
- **Gestión de Estado**: Zustand o Redux Toolkit
- **Manejo de Archivos**: APIs modernas
- **Procesamiento de Audio**: Soluciones basadas en la web

## Estructura del Proyecto
```
qobuz-downloader-v2
├── src
│   ├── components
│   ├── services
│   ├── hooks
│   ├── store
│   ├── utils
│   ├── types
│   ├── styles
│   ├── App.tsx
│   ├── main.tsx
│   └── vite-env.d.ts
├── server
│   ├── src
│   ├── package.json
│   └── tsconfig.json
├── docs
├── tests
├── public
├── package.json
├── tsconfig.json
├── vite.config.ts
├── tailwind.config.js
├── .gitignore
├── .env.example
└── README.md
```

## Instalación
1. Clona el repositorio:
   ```
   git clone <url-del-repositorio>
   ```
2. Navega al directorio del proyecto:
   ```
   cd qobuz-downloader-v2
   ```
3. Instala las dependencias:
   ```
   npm install
   ```
4. Inicia el servidor de desarrollo:
   ```
   npm run dev
   ```

## Contribuciones
Las contribuciones son bienvenidas. Si deseas contribuir, por favor abre un issue o envía un pull request.

## Licencia
Este proyecto está bajo la Licencia MIT. Consulta el archivo LICENSE para más detalles.

## Contacto
Para más información, puedes contactar al autor a través de [tu-email@example.com].